//
// Created by barti on 24.03.2025.
//

#ifndef MAT4X4_H
#define MAT4X4_H



class mat4x4 {

};



#endif //MAT4X4_H
